﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Sharp7;
using Pgres;

class ClientPart
{
    Postgre pg = new Postgre();
    static S7Client Client;

    // Max byte array size for reading each DataBlock form PLC 
    static byte[] DB_Float = new byte[1024];
    static byte[] DB_LongInt = new byte[1024];
    static byte[] DB_Int = new byte[1024];
    static byte[] DB_Bool = new byte[1024];

    static byte[] DB_FloatTemp = new byte[1024];
    static byte[] DB_LongIntTemp = new byte[1024];
    static byte[] DB_IntTemp = new byte[1024];
    static byte[] DB_BoolTemp = new byte[1024];

    // PLC conn. param.
    static string ipPLC;
    static int Rack;
    static int Slot;
    static int readCycle; //msec for whole multiread cycle

    // DataBlocks in PLC
    static int DBNumber_Float;
    static int DBNumber_LongInt;
    static int DBNumber_Int; 
    static int DBNumber_Bool;

    // Start byte to read form PLC (first byte = 0)
    static int StartByteFloat; //Starting from inserted byte ->  byte/4 = start signal)
    static int StartByteLongInt; //Starting from inserted byte ->  byte/4 = start signal)
    static int StartByteInt; //Starting from inserted byte ->  byte/4 = start signal)
    static int StartByteBool; //Starting from inserted byte (8 bits)

    // Number of signals to read form PLC
    static int NumSignalsFloat; //(will read inserted number of SIGNALS !!! -> not bytes)
    static int NumSignalsLongInt; //(will read inserted number of SIGNALS !!!  -> not bytes)
    static int NumSignalsInt; //(will read inserted number of SIGNALS !!!  -> not bytes)
    static int NumSignalsBool; //(will read inserted number of bytes)

    // BigEndian to LittleEndian conversion (for float(Single) or LongInt(int32) -> 4 bytes long)
    [StructLayout(LayoutKind.Explicit)]
    struct FloatDintStruct
    {
        [FieldOffset(0)] public byte byte0;
        [FieldOffset(1)] public byte byte1;
        [FieldOffset(2)] public byte byte2;
        [FieldOffset(3)] public byte byte3;
        [FieldOffset(0)] public float AsSingle;
        [FieldOffset(0)] public int AsInt32;

        public int BigEndToLittleEnd(byte[] bEnd)
        {
            this.byte0 = bEnd[3];
            this.byte1 = bEnd[2];
            this.byte2 = bEnd[1];
            this.byte3 = bEnd[0];
            return 0;
        }
    }

    // BigEndian to LittleEndian conversion (switching bytes in case of int -> 2 bytes long)
    [StructLayout(LayoutKind.Explicit)]
    struct IntStruct
    {
        [FieldOffset(0)] public byte byte0;
        [FieldOffset(1)] public byte byte1;
        [FieldOffset(0)] public short AsInt16;

        public int BigEndToLittleEnd(byte[] bEnd)
        {
            this.byte0 = bEnd[1];
            this.byte1 = bEnd[0];
            return 0;
        }
    }

    // Getting bit value on certain position in byte
    static bool GetBit(byte b, int bitPos)
    {
        return (1 == ((b >> bitPos) & 1));
    }

    // PLC connection
    static bool PlcConnect(string Address, int Rack, int Slot)
    {
        int res = Client.ConnectTo(Address, Rack, Slot);
        int Requested = Client.RequestedPduLength();
        int Negotiated = Client.NegotiatedPduLength();
        return res == 0;
    }

    // PLC Date and Time 
    static void DateAndTime()
    {
        DateTime DT = new DateTime();
        int res = Client.GetPlcDateTime(ref DT);

        Console.WriteLine(DT.ToLongDateString() + " - " + DT.ToLongTimeString());
    }

    // ##################### Atention !!!! - there is a limit in byte array lengt that can be read form PLC
    static int MultiRead()
    {
        // Multi Reader Instance
        S7MultiVar Reader = new S7MultiVar(Client);
        FloatDintStruct val = new FloatDintStruct();
        IntStruct intVal = new IntStruct();
        Postgre pg = new Postgre();

        //Float
        Reader.Add(S7Consts.S7AreaDB, S7Consts.S7WLReal, DBNumber_Float, StartByteFloat, NumSignalsFloat, ref DB_Float);
        int res = Reader.Read();

        if (Reader.Results[0]==0)
        {
            int j = 0;
            string insertSql;
            for (int i = StartByteFloat; i < (StartByteFloat + NumSignalsFloat); i++)
            {
                Array.Copy(DB_Float, j, DB_FloatTemp, 0, 4);
                val.BigEndToLittleEnd(DB_FloatTemp);
                insertSql = String.Format("INSERT INTO rt_values_real (real_dblock, real_byte, real_tag_value) " +
                                          "VALUES ({0}, {1}, {2});", DBNumber_Float, i, val.AsSingle);
                pg.pgQuery(insertSql);
                j = j + 4;
            }            
        }
        else
            Console.WriteLine("DB " + DBNumber_Float.ToString() + " " + Client.ErrorText(Reader.Results[0]));
        Reader.Clear();

        // LongInt
        Reader.Add(S7Consts.S7AreaDB, S7Consts.S7WLDInt, DBNumber_LongInt, StartByteLongInt, NumSignalsLongInt, ref DB_LongInt);
        res = Reader.Read();
        if (Reader.Results[0] == 0)
        {
            int j = 0;
            string insertSql;
            for (int i = StartByteLongInt; i < (StartByteLongInt + NumSignalsLongInt); i++)
            {
                Array.Copy(DB_LongInt, j, DB_LongIntTemp, 0, 4);
                val.BigEndToLittleEnd(DB_LongIntTemp);
                insertSql = String.Format("INSERT INTO rt_values_dint (dint_dblock, dint_byte, dint_tag_value) " +
                                          "VALUES ({0}, {1}, {2});", DBNumber_LongInt, i, val.AsInt32);
                pg.pgQuery(insertSql);
                j = j + 4;
            }
        }
        else
            Console.WriteLine("DB " + DBNumber_LongInt.ToString() + " " + Client.ErrorText(Reader.Results[0]));
        Reader.Clear();


        // Int
        Reader.Add(S7Consts.S7AreaDB, S7Consts.S7WLWord, DBNumber_Int, StartByteInt, NumSignalsInt, ref DB_Int);
        res = Reader.Read();
        if (Reader.Results[0] == 0)
        {
            int j = 0;
            string insertSql;
            for (int i = StartByteInt; i < (StartByteInt + NumSignalsInt); i++)
            {
                Array.Copy(DB_Int, j, DB_IntTemp, 0, 2);
                intVal.BigEndToLittleEnd(DB_IntTemp);
                insertSql = String.Format("INSERT INTO rt_values_int (int_dblock, int_byte, int_tag_value) " +
                                          "VALUES ({0}, {1}, {2});", DBNumber_Int, i, intVal.AsInt16);
                pg.pgQuery(insertSql);
                j = j + 2;
            }
        }
        else
            Console.WriteLine("DB " + DBNumber_Int.ToString() + " " + Client.ErrorText(Reader.Results[0]));
        Reader.Clear();

        // Bool
        Reader.Add(S7Consts.S7AreaDB, S7Consts.S7WLByte, DBNumber_Bool, StartByteBool, NumSignalsBool, ref DB_Bool);
        res = Reader.Read();
        if (Reader.Results[0] == 0)
        {
            int j = 0;
            string insertSql;
            for (int i = StartByteBool; i < (StartByteBool + NumSignalsBool); i++)
            {
                Array.Copy(DB_Bool, j, DB_BoolTemp, 0, 1);
                for (int k = 0; k < 8; k++)
                {
                    GetBit(DB_BoolTemp[0], k);
                    insertSql = String.Format("INSERT INTO rt_values_bool (bool_dblock, bool_byte, bool_bit, bool_tag_value) " +
                                              "VALUES ({0}, {1}, {2}, {3});", DBNumber_Bool, i, k, GetBit(DB_BoolTemp[0],k));
                    pg.pgQuery(insertSql);
                }
                j++ ;
            }
        }
        else
            Console.WriteLine("DB " + DBNumber_Int.ToString() + " " + Client.ErrorText(Reader.Results[0]));
        Reader.Clear();
        return 0;
    }

    static int checkEntryInt(string x)
    {
        int intResult=0;       
        while (!int.TryParse(x, out intResult))
        {
            Console.Write("The value must be integer, try again: \n");
            x = Console.ReadLine();
        }            
        return intResult;
    }


    //________________________________________________________________________________________________________________
    //
    //                                                    Main()                                    
    //________________________________________________________________________________________________________________
    public static void Main(string[] args)
    {
        Postgre pg = new Postgre();
        // Client creation
        Client = new S7Client();

        Console.Write("PLC IP address (enter three dots ... for default values): ");
        ipPLC = Console.ReadLine();

        if (ipPLC == "...") //Load default vaues
        {
            Console.WriteLine("Zero entered! \n " +
                              "Default vaues will be used \n " +
                              "PLC IP = 192.168.0.250, RACK = 0, SLOT = 2 \n " +
                              "DB_Float=151 reading first 20 signals \n " +
                              "DB_LongINT=152 reading first 10 signals \n " +
                              "DB_INT=153 reading first 10 signals \n " +
                              "DB_Bool=154 reading first 10bytes(80signals) \n ");

            //PLC connecion param.
            ipPLC = "192.168.0.250";
            Rack = 0;
            Slot = 2;
            readCycle = 2000;


            //float
            DBNumber_Float = 151;
            StartByteFloat = 0;
            NumSignalsFloat = 20;

            //LongInt
            DBNumber_LongInt = 152;
            StartByteLongInt = 0;
            NumSignalsLongInt = 10;

            //int
            DBNumber_Int = 153;
            StartByteInt = 0;
            NumSignalsInt = 10;

            //bool
            DBNumber_Bool = 154;
            StartByteBool = 0;
            NumSignalsBool = 4;
        }
        else
        {
            Console.WriteLine("Rack: ");
            Rack = checkEntryInt(Console.ReadLine());

            Console.WriteLine("Slot: ");
            Slot = checkEntryInt(Console.ReadLine());

            Console.WriteLine("Read cycle in msec: ");
            readCycle = checkEntryInt(Console.ReadLine());

            //float
            Console.WriteLine("Data Block for FLOAT signals: ");
            DBNumber_Float = checkEntryInt(Console.ReadLine());

            Console.WriteLine("Start byte to read: ");
            StartByteFloat = checkEntryInt(Console.ReadLine());

            Console.WriteLine("Number of signals to read: ");
            NumSignalsFloat = checkEntryInt(Console.ReadLine());

            //Dint
            Console.WriteLine("Data Block for DINT signals: ");
            DBNumber_LongInt = checkEntryInt(Console.ReadLine());

            Console.WriteLine("Start byte to read: ");
            StartByteLongInt = checkEntryInt(Console.ReadLine());

            Console.WriteLine("Number of signals to read: ");
            NumSignalsLongInt = checkEntryInt(Console.ReadLine());

            //Int
            Console.WriteLine("Data Block for INT signals: ");
            DBNumber_Int = checkEntryInt(Console.ReadLine());

            Console.WriteLine("Start byte to read: ");
            StartByteInt = checkEntryInt(Console.ReadLine());

            Console.WriteLine("Number of signals to read: ");
            NumSignalsInt = checkEntryInt(Console.ReadLine());

            //Bool
            Console.WriteLine("Data Block for BOOL signals: ");
            DBNumber_Bool = checkEntryInt(Console.ReadLine());

            Console.WriteLine("Start byte to read: ");
            StartByteBool = checkEntryInt(Console.ReadLine());

            Console.WriteLine("Number of BYTES to read (No. signals = Bytes x 8): ");
            NumSignalsBool = checkEntryInt(Console.ReadLine());
        }


        // Try Connection
        if (PlcConnect(ipPLC, Rack, Slot))        
        {
            int i = 0;
            DateTime startTime, endTime;                 
            Console.WriteLine("Connected to " + ipPLC.ToString() + " Rack: " + Rack.ToString() + " Slot: " + Slot.ToString());

            var timer = new System.Threading.Timer((e) =>
               {
                   startTime = DateTime.Now;
                   MultiRead();
                   endTime = DateTime.Now;
                   double elapsedTime = ((TimeSpan)(endTime - startTime)).TotalMilliseconds;
                   i++;
                   Console.WriteLine("Cycle No." + i.ToString() + "  duration: " + elapsedTime.ToString() + " msec.");
               }, null, TimeSpan.Zero, TimeSpan.FromMilliseconds(2000)
            );
            //timer.Dispose();
        }


        Console.ReadKey();
    }
}
