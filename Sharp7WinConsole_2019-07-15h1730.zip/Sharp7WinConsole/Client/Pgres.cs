﻿using System;
using System.Data;
using Npgsql;

namespace Pgres
{
    class Postgre
    {
        static string srvName, portNo, userName, userPass, dbaseName;

        public Postgre()
        {
            srvName = "127.0.0.1";
            portNo = "5432";
            dbaseName = "scadadb";
            userName = "postgres";
            userPass = "Pero123!";
        }

        private DataSet ds = new DataSet();

        private int connectToDb(string strSQL)
        {
            try
            {              
                string connstring = String.Format("Server={0};" +
                                                  "Port={1};" +
                                                  "Database={2};" +
                                                  "User Id={3};" +
                                                  "Password={4};", srvName, portNo, dbaseName, userName, userPass );
                // Making connection with Npgsql provider
                NpgsqlConnection conn = new NpgsqlConnection(connstring);
                conn.Open();
                NpgsqlCommand cmd = new NpgsqlCommand(strSQL, conn);
                NpgsqlDataReader dbReader = null;
                dbReader = cmd.ExecuteReader();
                while (dbReader.Read())
                {
                    Console.WriteLine(dbReader.GetValue(0).ToString());
                }
                conn.Close();
            }
            catch (Exception msg)
            {
                Console.WriteLine(msg.ToString());
                throw;
            }
            return 0;
        }

        public int pgQuery(string strSql) {
            connectToDb(strSql);            
            return 0;
        }

    }
}
